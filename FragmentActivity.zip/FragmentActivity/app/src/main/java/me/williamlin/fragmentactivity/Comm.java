package me.williamlin.fragmentactivity;

/**
 * Created by william on 2/24/18.
 */

public interface Comm {
    void onButtonClick(int font, String text);
}
